<?php

function physc_child_enqueue_styles() {
	wp_enqueue_style( 'physc-parent-style', get_template_directory_uri() . '/style.css', array(), PHYSC_THEME_VERSION  );
}

add_action( 'wp_enqueue_scripts', 'physc_child_enqueue_styles', 1000 );