<?php
function patistry_child_enqueue_styles() {
	wp_deregister_style( 'diazy-style' );
	$parent_style = 'parent-style';
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( $parent_style ) );
	if ( is_file( PATISTRY_UPLOADS_FOLDER . PATISTRY_FILE_NAME ) ) {
		wp_deregister_style( 'physcode_patistry' );
		wp_enqueue_style( 'physcode_patistry_child', PATISTRY_UPLOADS_URL . PATISTRY_FILE_NAME, array() );
	}
}

add_action( 'wp_enqueue_scripts', 'patistry_child_enqueue_styles', 11 );