<?php
 function uray_child_enqueue_styles() {
	wp_deregister_style( 'uray-style' );

	$parent_style = 'parent-style'; 
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array() , '1.0');
	wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( $parent_style ) ,'1.0');
	if ( is_file( URAY_UPLOADS_FOLDER . URAY_FILE_NAME ) ) {
		wp_deregister_style( 'uray-options' );
		wp_enqueue_style( 'uray-options-child', URAY_UPLOADS_URL . URAY_FILE_NAME, array(), filemtime( URAY_UPLOADS_FOLDER . URAY_FILE_NAME ) );
 	  }
}

add_action( 'wp_enqueue_scripts', 'uray_child_enqueue_styles', 11 );