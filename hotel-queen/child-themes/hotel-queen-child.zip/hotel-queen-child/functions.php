<?php
 function hotel_queen_child_enqueue_styles() {
	wp_deregister_style( 'hotel-queen-style' );

	$parent_style = 'parent-style';
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( $parent_style ) );
	if ( is_file( HOTEL_QUEEN_UPLOADS_FOLDER . HOTEL_QUEEN_FILE_NAME) ) {
		wp_deregister_style( 'physcode_hotel-queen' );
		wp_enqueue_style( 'physcode_hotel-queen_child', HOTEL_QUEEN_UPLOADS_URL .HOTEL_QUEEN_FILE_NAME, array() );
	}
}

add_action( 'wp_enqueue_scripts', 'hotel_queen_child_enqueue_styles', 11 ); 