<?php
 function hotel_queen_child_enqueue_styles() {
	wp_deregister_style( 'hotel-queen-style' );

	$parent_style = 'parent-style';
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( $parent_style ) );

}

add_action( 'wp_enqueue_scripts', 'hotel_queen_child_enqueue_styles', 11 );
