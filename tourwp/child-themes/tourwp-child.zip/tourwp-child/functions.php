<?php
 function tourwp_child_enqueue_styles() {
	wp_deregister_style( 'tourwp-style' );

	$parent_style = 'parent-style';
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( $parent_style ) );
	if ( is_file( TOURWP_UPLOADS_FOLDER . 'physcode_tourwp.css' ) ) {
		wp_deregister_style( 'physcode_tourwp' );
		wp_enqueue_style( 'physcode_tourwp_child', TOURWP_UPLOADS_URL . 'physcode_tourwp.css', array() );
	}
}

add_action( 'wp_enqueue_scripts', 'tourwp_child_enqueue_styles', 11 );