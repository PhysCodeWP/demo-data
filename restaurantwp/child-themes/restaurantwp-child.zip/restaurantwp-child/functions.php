<?php

function restaurantwp_child_enqueue_styles() {
	wp_deregister_style( 'restaurantwp-style' );

	$parent_style = 'parent-style';
	wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( $parent_style ) );
	if ( is_file( RESTAURANTWP_UPLOADS_FOLDER . 'physcode_restaurantwp.css' ) ) {
		wp_deregister_style( 'physcode_restaurantwp' );
		wp_enqueue_style( 'physcode_restaurantwp_child', RESTAURANTWP_UPLOADS_URL . 'physcode_restaurantwp.css', array() );
	}
}

add_action( 'wp_enqueue_scripts', 'restaurantwp_child_enqueue_styles', 11 );
